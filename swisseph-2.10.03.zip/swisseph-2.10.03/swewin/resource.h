//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by swewin.rc
//
#define IDD_DIALOG1                     101
#define IDR_MENU1                       107
#define IDB_BITMAP1                     110
#define IDC_EDIT1                       1000
#define EDIT_DAY                        1000
#define EDIT_OUTPUT                     1000
#define EDIT_MONTH                      1001
#define EDIT_YEAR                       1002
#define LABEL_DAY                       1003
#define LABEL_DATE                      1003
#define EDIT_ALT                        1004
#define EDIT_OUTPUT2                    1005
#define EDIT_ASTNO                      1006
#define EDIT_HOUR                       1007
#define EDIT_MINUTE                     1008
#define LABEL_TIME                      1009
#define COMBO_ET_UT                     1013
#define EDIT_LONG                       1015
#define EDIT_LONG_DEG                   1015
#define EDIT_LAT                        1016
#define EDIT_LAT_DEG                    1016
#define LABEL_LAT                       1017
#define LABEL_LONG                      1018
#define COMBO_EPHE                      1019
#define EDIT_LATM                       1020
#define EDIT_LAT_MIN                    1020
#define COMBO_PLANSEL                   1021
#define COMBO_AD_BC                     1022
#define COMBO_CENTER                    1022
#define EDIT_SECOND                     1023
#define EDIT_LONGM                      1024
#define EDIT_LONG_MIN                   1024
#define EDIT_LONGS                      1025
#define EDIT_LONG_SEC                   1025
#define COMBO_N_S                       1026
#define EDIT_LATS                       1027
#define EDIT_LAT_SEC                    1027
#define COMBO_E_W                       1028
#define ABOUT_L1                        1028
#define ABOUT_L2                        1029
#define LABEL_ASTNO                     1029
#define ABOUT_L3                        1030
#define PB_DOIT                         1031
#define COMBO_HSYS                      1032
#define IDC_RICHEDIT1                   1033
#define IDC_HELIO                       1034
#define LABEL_ALT                       1035
#define LABEL_METERS                    1036
#define LABEL_ALT2                      1037
#define ID_ABOUT                        40008
#define ID_RUN                          40011
#define MENU_CALC                       40011
#define ID_EXIT                         40012
#define MENU_EXIT                       40012
#define PB_EXIT                         40012
#define MENU_ABOUT                      40013

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        111
#define _APS_NEXT_COMMAND_VALUE         40014
#define _APS_NEXT_CONTROL_VALUE         1037
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
